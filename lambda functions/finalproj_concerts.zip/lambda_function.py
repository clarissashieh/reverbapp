#
# Python program to 
#

import requests
import json
import boto3
import os
import base64
import string

from configparser import ConfigParser

###################################################################
#
# classes
#
class Concert:
  def __init__(self, artist, body):
    self.artist = artist
    self.date = body['dates']
    self.location = body['location']
    self.link = body['url']

###################################################################
#
# web_service_get
#
# When calling servers on a network, calls can randomly fail. 
# The better approach is to repeat at least N times (typically 
# N=3), and then give up after N tries.
#
def web_service_get(url):
  """
  Submits a GET request to a web service at most 3 times, since 
  web services can fail to respond e.g. to heavy user or internet 
  traffic. If the web service responds with status code 200, 400 
  or 500, we consider this a valid response and return the response.
  Otherwise we try again, at most 3 times. After 3 attempts the 
  function returns with the last response.
  
  Parameters
  ----------
  url: url for calling the web service
  
  Returns
  -------
  response received from web service
  """

  try:
    retries = 0
    
    while True:
      response = requests.get(url)
        
      if response.status_code in [200, 400, 480, 481, 482, 500]:
        #
        # we consider this a successful call and response
        #
        break;

      #
      # failed, try again?
      #
      retries = retries + 1
      if retries < 3:
        # try at most 3 times
        time.sleep(retries)
        continue
          
      #
      # if get here, we tried 3 times, we give up:
      #
      break

    return response

  except Exception as e:
    print("**ERROR**")
    logging.error("web_service_get() failed:")
    logging.error("url: " + url)
    logging.error(e)
    return None

def lambda_handler(event, context):
  try:
    print("**STARTING**")
    print("**lambda: finalproj_concerts**")
    
    # 
    # in case we get an exception, initial this filename
    # so we can write an error message if need be:
    #
    bucketkey_results_file = ""
    
    #
    # setup AWS based on config file:
    #
    config_file = 'reverbapp-config.ini'
    os.environ['AWS_SHARED_CREDENTIALS_FILE'] = config_file
    
    configur = ConfigParser()
    configur.read(config_file)
  
    #
    # configure for S3 access:
    #
    s3_profile = 's3readwrite'
    boto3.setup_default_session(profile_name=s3_profile)
    
    bucketname = configur.get('s3', 'bucket_name')
    
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(bucketname)
    
    #
    # get spotify and ticketmaster api baseurls
    #
    spotifybaseurl = configur.get('spotify', 'webservice')

    #
    # make sure baseurl does not end with /, if so remove:
    #
    lastchar = spotifybaseurl[len(spotifybaseurl) - 1]
    if lastchar == "/":
      spotifybaseurl = spotifybaseurl[:-1]

    ticketmasterbaseurl = configur.get('ticketmaster', 'webservice')
    lastchar = ticketmasterbaseurl[len(ticketmasterbaseurl) - 1]
    if lastchar == "/":
      ticketmasterbaseurl = ticketmasterbaseurl[:-1]

    #
    # get access token from Spotify API
    #
    client_id = configur.get('spotify', 'client_id')
    client_secret = configur.get('spotify', 'client_secret')

    auth_header = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()

    auth_url = 'https://accounts.spotify.com/api/token'
    headers = {
        'Authorization': f'Basic {auth_header}'
    }
    data = {
        'grant_type': 'client_credentials'
    }

    res = requests.post(auth_url, headers=headers, data=data)
    
    if res.status_code == 200: #success
      pass
    else:
      # failed:
      print("Failed with status code:", res.status_code)
      print("url: " + url)
      if res.status_code == 500:
        # we'll have an error message
        body = res.json()
        print("Error message:", body)
      #
      return

    body = res.json()
    token = body['access_token']

    # 
    # get top 5 artists with Spotify API
    #
    print("**Searching Spotify API for user's top artists**")
    api = '/me/top/artists?'
    url = spotifybaseurl + api
    params = {
      "Authorization": "Bearer" + access_token,
      "limit": "5"
    }

    res = requests.get(url, params)

    if res.status_code == 200: #success
      pass
    else:
      # failed:
      print("Failed with status code:", res.status_code)
      print("url: " + url)
      if res.status_code == 500:
        # we'll have an error message
        body = res.json()
        print("Error message:", body)
      #
      return
    
    body = res.json()
    items = body['items']
    
    artists = []
    for item in items:
      artist = item['name']
      artists.append(artist)

    print("**COMPLETE**")

    # 
    # search for next 3 attractions with Ticketmaster API for each top artist
    #
    print("**Searching Ticketmaster API for **")
    consumer_key = configur.get('ticketmaster', 'consumer_key')
    
    concerts = []
    # find next concerts for each top artist
    for artist in artists:
      api = '/events.json?'
      url = ticketmasterbaseurl + api
      params = {
        "apikey": "consumer_key",
        "size": "1",
        "classificationName": "Music",
        "keyword": artist
      }

      res = requests.get(url, params)

      if res.status_code == 200: #success
        pass
      else:
        # failed:
        print("Failed with status code:", res.status_code)
        print("url: " + url)
        if res.status_code == 500:
          # we'll have an error message
          body = res.json()
          print("Error message:", body)
        #
        return
      
      body = res.json()
      results = body['events']

      # get details for each result
      for result in results:
        id = result['id']
        api = '/events/' + id
        url = ticketmasterbaseurl + api
        
        res = requests.get(url, params)

        if res.status_code == 200: #success
          pass
        else:
          # failed:
          print("Failed with status code:", res.status_code)
          print("url: " + url)
          if res.status_code == 500:
            # we'll have an error message
            body = res.json()
            print("Error message:", body)
          #
          return
        
        body = res.json()
        concerts.append(Concert(artist, body))

    print("**COMPLETE**")

    #
    # list upcoming concerts
    #
    print("Upcoming concerts:")
    for concert in concerts:
      print(concert + "\n")

    return {
      'statusCode': 200,
      'body': json.dumps(concerts)
    }
    
  except Exception as err:
    print("**ERROR**")
    print(str(err))
    
    return {
      'statusCode': 500,
      'body': json.dumps(str(err))
    }
